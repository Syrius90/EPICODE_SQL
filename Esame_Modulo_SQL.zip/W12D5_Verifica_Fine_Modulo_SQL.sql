/*ToysGroup è un’azienda che distribuisce articoli (giocatoli) in diverse aree geografiche del mondo.
I prodotti sono classificati in categorie e i mercati di riferimento dell’azienda sono classificati in regioni di vendita.
In particolare: Le entità individuabili in questo scenario sono le seguenti:
	❏- Product: IdProduct PK, Product_Name, Product_Category
    ❏- Region: IdRegion PK, Country
    ❏- Sales: IdSale PK, Date, Unit_Price, Quantity, Tot_Price (unit_price * quantity), Idproduct FK, IdRegion FK
Le relazioni tra le entità possono essere descritte nel modo seguente:
❏ Product e Sales
	❏ Un prodotto può essere venduto tante volte (o nessuna) per cui è contenuto in una o più transazioni di vendita.
	❏ Ciascuna transazione di vendita è riferita ad uno solo prodotto
❏ Region e Sales
	❏ Possono esserci molte o nessuna transazione per ciascuna regione
	❏ Ciascuna transazione di vendita è riferita ad una sola regione */
    
CREATE SCHEMA `toysgroup` ;
    
USE toysgroup;
    
CREATE TABLE `toysgroup`.`product` (
  `IdProduct` INT NOT NULL AUTO_INCREMENT,
  `Product_Name` VARCHAR(45) NOT NULL,
  `Product_Category` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`IdProduct`));
  
  CREATE TABLE `toysgroup`.`region` (
  `IdRegion` INT NOT NULL AUTO_INCREMENT,
  `Country` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`IdRegion`));
  
  CREATE TABLE `toysgroup`.`sales` (
  `IdSales` INT NOT NULL AUTO_INCREMENT,
  `Date` DATE NOT NULL,
  `Unit_Price` DECIMAL(10,2) NOT NULL,
  `Quantity` INT NOT NULL,
  `Total_Price` DECIMAL(15,2) NOT NULL,
  `IdProduct` INT NOT NULL,
  `IdRegion` INT NOT NULL,
  PRIMARY KEY (`IdSales`),
  INDEX `sales_product_idx` (`IdProduct` ASC) VISIBLE,
  INDEX `sales_region_idx` (`IdRegion` ASC) VISIBLE,
  CONSTRAINT `sales_product`
    FOREIGN KEY (`IdProduct`)
    REFERENCES `toysgroup`.`product` (`IdProduct`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `sales_region`
    FOREIGN KEY (`IdRegion`)
    REFERENCES `toysgroup`.`region` (`IdRegion`)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
/*Crea e popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella;riporta le query utilizzate).*/
    
    INSERT INTO product (Product_Name, Product_Category)
VALUES
  ('Bambola Barbie', 'Bambole'),
  ('Macchina Telecomandata', 'Veicoli'),
  ('Set di Cucina Giocattolo', 'Cucina'),
  ('Blocchi Lego', 'Costruzione'),
  ('Puzzle', 'Giochi da Tavolo'),
  ('Palline da Calcio', 'Sport'),
  ('Orsetto di Peluche', 'Animali di Peluche'),
  ('Trenino Elettrico', 'Veicoli'),
  ('Tende per Bambini', 'Giochi da Esterno'),
  ('Piscina Gonfiabile', 'Giochi da Esterno'),
  ('Giochi di Carte', 'Giochi da Tavolo'),
  ('Disegni da Colorare', 'Attività Artistiche'),
  ('Pasta Modellabile', 'Attività Artistiche'),
  ('Strumenti Musicali Giocattolo', 'Musica'),
  ('Microscopio Giocattolo', 'Scienza'),
  ('Telescopio Giocattolo', 'Scienza'),
  ('Registratore di Cassa Giocattolo', 'Giochi di Ruolo'),
  ('Cucina Giocattolo', 'Giochi di Ruolo');

INSERT INTO region (Country)
VALUES
  ('Italia'),
  ('Francia'),
  ('Germania'),
  ('Spagna'),
  ('Regno Unito'),
  ('Canada'),
  ('Cina'),
  ('USA'),
  ('Giappone'),
  ('Australia');

INSERT INTO sales (Date, Unit_Price, Quantity, Total_Price, IdProduct, IdRegion)
VALUES
  ('2014-08-24', 19.99, 1, 19.99, 16, 9),
  ('2013-07-11', 59.99, 1, 59.99, 18, 5),
  ('2018-03-02', 9.99, 4, 39.96, 11, 7),
  ('2021-12-17', 24.99, 2, 49.98, 17, 4),
  ('2017-02-09', 14.99, 5, 74.95, 13, 6),
  ('2012-06-28', 3.99, 1, 3.99, 10, 3),
  ('2023-05-23', 24.99, 3, 74.97, 5, 9),
  ('2015-10-04', 14.99, 4, 59.96, 13, 2),
  ('2019-09-21', 9.99, 2, 19.98, 11, 10),
  ('2020-04-15', 19.99, 1, 19.99, 6, 2),
  ('2016-01-12', 12.99, 2, 25.98, 5, 9),
  ('2022-08-06', 59.99, 1, 59.99, 18, 5),
  ('2014-02-14', 9.99, 5, 49.95, 11, 7),
  ('2020-11-27', 19.99, 3, 59.97, 14, 1),
  ('2013-05-10', 3.99, 1, 3.99, 10, 3),
  ('2019-02-20', 24.99, 1, 24.99, 17, 2),
  ('2017-11-02', 14.99, 5, 74.95, 13, 8),
  ('2023-06-24', 49.99, 1, 49.99, 15, 6),
  ('2015-03-09', 9.99, 3, 29.97, 11, 4),
  ('2021-12-16', 19.99, 2, 39.98, 6, 9);


    

/*Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a:*/
-- 1. Verificare che i campi definiti come PK siano univoci.
-- Se utilizzando Count sulle chiave primarie e poi sulle chiave primarie attraverso Distinct otteniamo lo stesso risultato allora i valori sono univoci
SELECT
	COUNT(p.IdProduct)
FROM
	product p;
    
SELECT DISTINCT
	COUNT(p.IdProduct)
FROM
	product p;
    
SELECT
	COUNT(r.IdRegion)
FROM
	region r;
    
SELECT DISTINCT
	COUNT(r.IdRegion)
FROM
	region r;
    
SELECT
	COUNT(s.IdSales)
FROM
	sales s;
    
SELECT DISTINCT
	COUNT(s.IdSales)
FROM
	sales s;
    
-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
-- Inner Join delle tabelle sales e product esclude i prodotti non venduti
SELECT
	p.Product_Name,
    YEAR(s.Date) Anno,
    SUM(s.Total_Price) Fatturato_Totale
FROM
	sales s
		JOIN
	product p ON s.IdProduct = p.IdProduct
GROUP BY p.Product_Name, YEAR(s.Date)
ORDER BY p.Product_Name;

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT
	r.Country,
    YEAR(s.Date) Anno,
    SUM(s.Total_Price) Fatturato_Totale
FROM
	sales s
		JOIN
	region r ON s.IdRegion = r.IdRegion
GROUP BY r.Country, YEAR(s.Date)
ORDER BY Anno, Fatturato_Totale DESC;

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
-- Maggiore quantita venduta
SELECT
	p.Product_Category,
    SUM(s.Quantity) Totale_Quantita_Venduta
FROM
	sales s
		RIGHT JOIN
	product p ON s.IdProduct = p.IdProduct
GROUP BY p.Product_Category
ORDER BY Totale_Quantita_Venduta DESC
LIMIT 1;

-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
-- mettendo in relazione le tabelle con join e right join visualizzando tutti i prodotti i cui id non compaiono nell'insieme più stretto
SELECT
	p.*
FROM
	sales s
		RIGHT JOIN
	product p ON s.IdProduct = p.IdProduct
WHERE
	p.IdProduct NOT IN
	(SELECT
		s.IdProduct
	FROM
		sales s
			JOIN
		product p ON s.IdProduct = p.IdProduct);

-- Conteggio delle volte in cui l'id prodotto compare nelle transazioni
SELECT
	p.Product_Name,
    COUNT(s.IdProduct) Numero_Transazioni_Prodotto
FROM
	sales s
		RIGHT JOIN
	product p ON s.IdProduct = p.IdProduct
GROUP BY p.Product_Name
HAVING Numero_Transazioni_Prodotto = 0;

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT
	p.*,
	a.Ultima_Data_Vendita
FROM
	product p
		LEFT JOIN
	(SELECT
		s.IdProduct,
		MAX(s.DATE) Ultima_Data_Vendita
	FROM
		sales s
	GROUP BY s.IdProduct) AS a ON p.IdProduct = a.IdProduct;